const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const axios = require('axios');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// Secret key untuk JWT
// const secretKey = 'your_secret_key_here';


app.post('/v1/auth/login', async (req, res) => {
  const { user, password } = req.body;
  delete req.headers.host;
  delete req.headers.referer;
  try {
    // res.json({ user, password });
    const response = await axios.post('https://test-p3-api-gw-public-113028295.ap-southeast-1.elb.amazonaws.com:443/v1/auth/login', {
      password,
      user,
    }).then((response) => {
      // console.log(response);
      // const token = response.data.token;
      res.json({ response });
    });;
  } catch (error) {
    res.status(401).json({ error });
  }
});


const verifyToken = (req, res, next) => {
  const token = req.header('X-Auth-Token');
  if (!token) return res.status(401).json({ message: 'Access denied' });
  
  try {
    const decoded = jwt.verify(token, secretKey);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid token' });
  }
};
app.post('/v1/member/describe', verifyToken, async (req, res) => {
  const { target } = req.body;
  try {
    const response = await axios.post('https://test-p3-api-gw-public-113028295.ap-southeast-1.elb.amazonaws.com:443/v1/member/describe', {
      target,
    }, {
      headers: {
        'X-Auth-Token': req.header('X-Auth-Token'),
      },
    });
    res.json(response.data);
  } catch (error) {
    res.status(401).json({ message: 'Unauthorized' });
  }
});
app.listen(port, () => {
  console.log(`Server berjalan di port ${port}`);
});